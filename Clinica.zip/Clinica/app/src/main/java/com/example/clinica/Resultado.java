package com.example.clinica;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import java.util.ArrayList;

public class Resultado extends AppCompatActivity {
    private EditText txtNome;
    private RadioGroup rbgSexo;
    private EditText txtPeso;
    private EditText txtAltura;
    private Button btnCadastrar;
    private RadioButton rbtFeminino;
    private RadioButton rbtMasculino;
    private Button btnLimpar;
    private Button btnResultado;
    private ArrayList listaPaciente = null;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultado);

        txtNome = (EditText) findViewById(R.id.txtNome);
        rbgSexo= findViewById(R.id.rbgSexo);
        txtPeso= findViewById(R.id.txtPeso);
        txtAltura=(EditText) findViewById(R.id.txtAltura);
        btnCadastrar= findViewById(R.id.btnCadastrar);
        rbtMasculino= findViewById(R.id.rbtMasculino);
        rbtFeminino= findViewById(R.id.rbtFeminino);
        btnLimpar= findViewById(R.id.btnLimpar);
        btnResultado= findViewById(R.id.btnResultado);

        Intent it = getIntent();
        String quantidade = it.getStringExtra("tipo");

    }
}