package com.example.clinica;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private EditText txtNome;
    private RadioGroup rbgSexo;
    private EditText txtPeso;
    private EditText txtAltura;
    private Button btnCadastrar;
    private RadioButton rbtFeminino;
    private RadioButton rbtMasculino;
    private Button btnLimpar;
    private Button btnResultado;
    private ArrayList listaPaciente = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtNome = findViewById(R.id.txtNome);
        rbgSexo= findViewById(R.id.rbgSexo);
        txtPeso= findViewById(R.id.txtPeso);
        txtAltura=(EditText) findViewById(R.id.txtAltura);
        btnCadastrar= findViewById(R.id.btnCadastrar);
        rbtMasculino= findViewById(R.id.rbtMasculino);
        rbtFeminino= findViewById(R.id.rbtFeminino);
        btnLimpar= findViewById(R.id.btnLimpar);
        btnResultado= findViewById(R.id.btnResultado);


        btnLimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                txtNome.setText(" ");
                txtAltura.setText(" ");
                txtPeso.setText(" ");
                rbtMasculino.setChecked(false);
                rbtFeminino.setChecked(false);

            }
        });

        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Paciente pacientes = new Paciente();

                pacientes.setNome(txtNome.getText().toString());
                pacientes.setAltura(Double.parseDouble(txtAltura.getText().toString()));
                pacientes.setPeso(Double.parseDouble(txtPeso.getText().toString()));

                if(rbtFeminino.isChecked())
                    pacientes.setSexo(0);
                else if(rbtMasculino.isChecked())
                    pacientes.setSexo(1);

                listaPaciente.add(pacientes);

            }

            private int quantidade(List<Paciente> pacientes)
            {
                return pacientes.size();
            }

            private int idade(List<Paciente> pacientes)

            }


        });

        btnResultado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                for (int i=0; i < listaPaciente.size(); i++)
                {
                    Paciente resultadoPaciente =(Paciente) listaPaciente.get(i);
                }
                Intent it = new Intent(this, Resultado.class);
                it.putExtra("Quantidade", quantidade());
                it.putExtra("Idade", );
                it.putExtra("Nome mais velho", );


                startActivity(it);

            }
        });



    }
}