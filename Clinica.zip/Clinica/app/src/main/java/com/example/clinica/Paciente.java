package com.example.clinica;

import java.util.ArrayList;
import java.util.List;

public class Paciente
{
    private String nome;
    private int sexo;
    private double peso;
    private double altura;

    public Paciente(){

    }

    public Paciente(String nome, int sexo, double peso, double altura) {
        this.nome = nome;
        this.sexo = sexo;
        this.peso = peso;
        this.altura = altura;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getSexo() {
        return sexo;
    }


    public void setSexo(int sexo) {
        this.sexo = sexo;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }


}
